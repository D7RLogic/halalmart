<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ZakatCalculatorController;
use App\Http\Controllers\AuthController;

Route::get('/', [HomeController::class, 'index'])->name('home');

Route::get('/category/{category}', [HomeController::class, 'filterByCategory'])->name('category.filter');

Route::get('/product/{id}', [ProductController::class, 'show'])->name('product.show');

Route::get('/checkout', [CheckoutController::class, 'showForm'])->name('checkout.form');
Route::post('/checkout', [CheckoutController::class, 'processForm'])->name('checkout.process');

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

Route::prefix('admin')->middleware('auth')->group(function () {
    // Product management
    Route::get('/products/create', [\App\Http\Controllers\ProductController::class, 'create'])->name('admin.products.create');
    Route::post('/products', [\App\Http\Controllers\ProductController::class, 'store'])->name('admin.products.store');
    Route::get('/products', [\App\Http\Controllers\ProductController::class, 'index'])->name('admin.products.index');
    Route::get('/products/{id}/edit', [\App\Http\Controllers\ProductController::class, 'edit'])->name('admin.products.edit');
    Route::put('/products/{id}', [\App\Http\Controllers\ProductController::class, 'update'])->name('admin.products.update');
    Route::delete('/products/{id}', [\App\Http\Controllers\ProductController::class, 'destroy'])->name('admin.products.destroy');

    // Transaction dashboard
    Route::get('/dashboard', [\App\Http\Controllers\DashboardController::class, 'adminDashboard'])->name('admin.dashboard');

    // Financial report
    Route::get('/reports/financial', [\App\Http\Controllers\DashboardController::class, 'financialReport'])->name('admin.reports.financial');

    // UMKM add and store routes
    Route::get('/umkm/add', [\App\Http\Controllers\DashboardController::class, 'showAddUmkmForm'])->name('admin.umkm.add');
    Route::post('/umkm/store', [\App\Http\Controllers\DashboardController::class, 'storeUmkm'])->name('admin.umkm.store');
});

Route::get('/zakat-calculator', [ZakatCalculatorController::class, 'index'])->name('zakat.calculator');
Route::post('/zakat-calculate', [ZakatCalculatorController::class, 'calculate'])->name('zakat.calculate');
Route::get('/pengertian-zakat', [ZakatCalculatorController::class, 'pengertian'])->name('pengertian.zakat');

// Authentication routes
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');

Route::get('/purchase-summary', [\App\Http\Controllers\CheckoutController::class, 'purchaseSummary'])->name('purchase.summary');
Route::post('/purchase-confirm', [\App\Http\Controllers\CheckoutController::class, 'confirmPurchase'])->name('purchase.confirm');
Route::post('/login', [AuthController::class, 'login'])->name('login.process');

Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register'])->name('register.process');

Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
