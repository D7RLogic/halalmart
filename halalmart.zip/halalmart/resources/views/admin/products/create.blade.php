@extends('layouts.app')

@section('title', 'Add New Product')

@section('content')
<h1>Add New Product</h1>

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('admin.products.store') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="mb-3">
        <label for="name" class="form-label">Product Name *</label>
        <input type="text" class="form-control" id="name" name="name" value="{{ old('name') }}" required>
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea class="form-control" id="description" name="description">{{ old('description') }}</textarea>
    </div>
    <div class="mb-3">
        <label for="price" class="form-label">Price (Rp) *</label>
        <input type="number" class="form-control" id="price" name="price" value="{{ old('price') }}" min="0" step="0.01" required>
    </div>
    <div class="mb-3">
        <label for="category" class="form-label">Category</label>
        <input type="text" class="form-control" id="category" name="category" value="{{ old('category') }}">
    </div>
    <div class="mb-3">
        <label for="image" class="form-label">Product Image (jpg, png, max 2MB)</label>
        <input type="file" class="form-control" id="image" name="image" accept="image/*">
    </div>
    <div class="mb-3">
        <label for="halal_certification" class="form-label">Halal Certification (pdf, jpg, png, max 5MB)</label>
        <input type="file" class="form-control" id="halal_certification" name="halal_certification" accept=".pdf,image/*">
    </div>
    <div class="mb-3">
        <label for="halal_status" class="form-label">Halal Status</label>
        <input type="text" class="form-control" id="halal_status" name="halal_status" value="Unknown" readonly>
    </div>
    <button type="submit" class="btn btn-primary">Add Product</button>
    <a href="{{ route('admin.dashboard') }}" class="btn btn-secondary">Cancel</a>
</form>

    <script>
    document.getElementById('halal_certification').addEventListener('change', function(event) {
        const fileInput = event.target;
        const halalStatusInput = document.getElementById('halal_status');
        if (fileInput.files.length === 0) {
            // Default to halal if no file selected
            halalStatusInput.value = 'halal';
            return;
        }
        const fileName = fileInput.files[0].name.toLowerCase();

        // Product Product Haram yang nanti auto ditolak
        const haramKeywords = ['babi', 'pork', 'alkohol', 'alcohol', 'wine', 'beer', 'whiskey', 'vodka'];

        let isHaram = haramKeywords.some(keyword => fileName.includes(keyword));

        if (isHaram) {
            halalStatusInput.value = 'haram';
        } else {
            halalStatusInput.value = 'halal';
        }
    });
    </script>
@endsection
