@extends('layouts.app')

@section('title', 'Edit Product')

@section('content')
<h1>Edit Product</h1>

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('admin.products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <div class="mb-3">
        <label for="name" class="form-label">Product Name *</label>
        <input type="text" class="form-control" id="name" name="name" value="{{ old('name', $product->name) }}" required>
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea class="form-control" id="description" name="description">{{ old('description', $product->description) }}</textarea>
    </div>
    <div class="mb-3">
        <label for="price" class="form-label">Price (Rp) *</label>
        <input type="number" class="form-control" id="price" name="price" value="{{ old('price', $product->price) }}" min="0" step="0.01" required>
    </div>
    <div class="mb-3">
        <label for="category" class="form-label">Category</label>
        <input type="text" class="form-control" id="category" name="category" value="{{ old('category', $product->category) }}">
    </div>
    <div class="mb-3">
        <label for="image" class="form-label">Product Image (jpg, png, max 2MB)</label>
        @if($product->image)
            <div class="mb-2">
                <img src="{{ asset('storage/' . $product->image) }}" alt="Product Image" style="max-width: 200px;">
            </div>
        @endif
        <input type="file" class="form-control" id="image" name="image" accept="image/*">
    </div>
    <div class="mb-3">
        <label for="halal_certification" class="form-label">Halal Certification (pdf, jpg, png, max 5MB)</label>
        @if($product->halal_certification)
            <div class="mb-2">
                <a href="{{ asset('storage/' . $product->halal_certification) }}" target="_blank">View Current Certification</a>
            </div>
        @endif
        <input type="file" class="form-control" id="halal_certification" name="halal_certification" accept=".pdf,image/*">
    </div>
    <button type="submit" class="btn btn-primary">Update Product</button>
    <a href="{{ route('admin.dashboard') }}" class="btn btn-secondary">Cancel</a>
</form>
@endsection
