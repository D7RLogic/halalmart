@extends('layouts.app')

@section('title', 'Manage Products')

@section('content')
<h1>Manage Products</h1>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

<a href="{{ route('admin.products.create') }}" class="btn btn-primary mb-3">Add New Product</a>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th>
            <th>Category</th>
            <th>Price (Rp)</th>
            <th>Image</th>
            <th>Halal Certification</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @forelse($products as $product)
        <tr>
            <td>{{ $product->name }}</td>
            <td>{{ $product->category }}</td>
            <td>{{ number_format($product->price, 2, ',', '.') }}</td>
            <td>
                @if($product->image)
                    <img src="{{ asset('storage/' . $product->image) }}" alt="Product Image" style="max-width: 100px;">
                @else
                    -
                @endif
            </td>
            <td>
                @if($product->halal_certification)
                    @php
                        $ext = pathinfo($product->halal_certification, PATHINFO_EXTENSION);
                    @endphp
                    @if(in_array(strtolower($ext), ['jpg', 'jpeg', 'png', 'gif']))
                        <img src="{{ asset('storage/' . $product->halal_certification) }}" alt="Halal Certification" style="max-width: 100px;">
                    @else
                        <a href="{{ asset('storage/' . $product->halal_certification) }}" target="_blank">View</a>
                    @endif
                @else
                    -
                @endif
            </td>
            <td>
                <a href="{{ route('admin.products.edit', $product->id) }}" class="btn btn-sm btn-warning">Edit</a>
                <form action="{{ route('admin.products.destroy', $product->id) }}" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this product?');">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="6" class="text-center">No products found.</td>
        </tr>
        @endforelse
    </tbody>
</table>

{{ $products->links() }}

@endsection
