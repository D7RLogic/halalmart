<script>
document.getElementById('halal_certification').addEventListener('change', function(event) {
    const fileInput = event.target;
    const halalStatusInput = document.getElementById('halal_status');
    if (fileInput.files.length === 0) {
        halalStatusInput.value = 'Unknown';
        return;
    }
    const fileName = fileInput.files[0].name.toLowerCase();

    // Simple keyword detection for Haram products
    const haramKeywords = ['babi', 'pork', 'alkohol', 'alcohol', 'wine', 'beer', 'whiskey', 'vodka'];

    let isHaram = haramKeywords.some(keyword => fileName.includes(keyword));

    if (isHaram) {
        halalStatusInput.value = 'Haram';
    } else {
        halalStatusInput.value = 'Halal';
    }
});
</script>
@endsection
