@extends('layouts.app')

@section('title', 'Admin Dashboard')

@section('content')
<h1>Admin Dashboard</h1>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

<div class="row">
    <div class="col-md-4">
        <div class="card text-white bg-primary mb-3">
            <div class="card-header">Total Products</div>
            <div class="card-body">
                <h3 class="card-title">{{ $productsCount }}</h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-success mb-3">
            <div class="card-header">Total Sales</div>
            <div class="card-body">
                <h3 class="card-title">Rp {{ number_format($totalSales, 2, ',', '.') }}</h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-info mb-3">
            <div class="card-header">Total Orders</div>
            <div class="card-body">
                <h3 class="card-title">{{ $totalOrders }}</h3>
            </div>
        </div>
    </div>
</div>

<a href="{{ route('admin.products.create') }}" class="btn btn-primary mb-3">Add New Product</a>
<a href="{{ route('admin.umkm.add') }}" class="btn btn-secondary mb-3 ms-2">Add New UMKM Partner</a>

{{-- TODO: Add more dashboard content such as recent orders, charts, etc. --}}
@endsection
