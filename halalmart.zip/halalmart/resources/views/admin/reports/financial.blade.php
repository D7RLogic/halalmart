@extends('layouts.app')

@section('title', 'Financial Report')

@section('content')
<div class="container mt-4">
    <h1>Financial Report</h1>

    @if($orders->isEmpty())
        <p>No financial data available.</p>
    @else
        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Product Name</th>
                    <th>Price (Rp)</th>
                </tr>
            </thead>
            <tbody>
                @foreach($orders as $order)
                <tr>
                    <td>{{ $order->product ? $order->product->name : 'N/A' }}</td>
                    <td>{{ number_format($order->total, 2, ',', '.') }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    @endif

    <a href="{{ route('admin.dashboard') }}" class="btn btn-primary mt-3">Back to Dashboard</a>
</div>
@endsection
