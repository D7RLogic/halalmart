@extends('layouts.app')

@section('title', 'Detail Produk')

@section('content')
<div class="row">
    <div class="col-md-6">
        @if($product->image)
        <img src="{{ asset('storage/' . $product->image) }}" class="img-fluid" alt="{{ $product->name }}">
        @else
        <img src="https://via.placeholder.com/400" class="img-fluid" alt="{{ $product->name }}">
        @endif
    </div>
    <div class="col-md-6">
        <h1>{{ $product->name }}</h1>
        <p>{{ $product->description }}</p>
        <h3>Harga: Rp {{ number_format($product->price, 0, ',', '.') }}</h3>
        <a href="{{ route('checkout.form', ['product' => $product->id]) }}" class="btn btn-success">Beli Sekarang</a>
    </div>
</div>
@endsection
