@extends('layouts.app')

@section('title', 'Dashboard UMKM')

@section('content')
<h1><p>Dashboard UMKM</p></h1>
<h5><p>Selamat datang di dashboard UMKM </p></h5>
<h5><p>Berikut adalah mitra mitra yang telah tergabung dengan kita</p></h5>

@if($umkms->isEmpty())
    <p>Tidak ada data UMKM yang tersedia.</p>
@else
    <div class="row row-cols-1 row-cols-md-3 g-4">
        @foreach($umkms as $umkm)
            <div class="col">
                <div class="card h-100">
                    @if($umkm->foto)
                        <img src="{{ asset('uploads/umkm/' . $umkm->foto) }}" class="card-img-top" alt="{{ $umkm->nama_umkm }}" style="object-fit: cover; height: 200px;">
                    @else
                        <img src="https://via.placeholder.com/300x200?text=No+Image" class="card-img-top" alt="No Image">
                    @endif
                    <div class="card-body">
                        <h5 class="card-title">{{ $umkm->nama_umkm }}</h5>
                        <p class="card-text"><strong>Alamat:</strong> {{ $umkm->alamat }}</p>
                        <p class="card-text"><strong>Kode Pos:</strong> {{ $umkm->kode_pos }}</p>
                        <p class="card-text"><strong>Nama Pemilik:</strong> {{ $umkm->nama_pemilik }}</p>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endif

@endsection
