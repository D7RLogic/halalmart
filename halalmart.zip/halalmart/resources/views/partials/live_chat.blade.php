<div id="live-chat" style="position: fixed; bottom: 20px; right: 20px; width: 300px; max-height: 400px; background: white; border: 1px solid #ccc; border-radius: 5px; box-shadow: 0 0 10px rgba(0,0,0,0.1); display: flex; flex-direction: column;">
    <div style="background: #28a745; color: white; padding: 10px; font-weight: bold; cursor: pointer;">
        Live Chat (Coming Soon)
    </div>
    <div style="flex: 1; padding: 10px; overflow-y: auto;">
        <p>Coming Soon...</p>
    </div>
    <div style="padding: 10px; border-top: 1px solid #ccc;">
        <input type="text" placeholder="Type a message..." style="width: 100%; padding: 5px;" disabled>
    </div>
</div>
