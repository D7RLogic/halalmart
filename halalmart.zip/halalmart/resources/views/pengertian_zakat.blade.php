@extends('layouts.app')

@section('title', 'Pengertian Zakat')

@section('content')
<div class="card mx-auto" style="max-width: 900px;">
    <div class="card-body">
        <h1 class="card-title mb-4">Pengertian Zakat</h1>

        <p>Pengertian Zakat Secara bahasa Zakat diartikan sebagai pengembangan barakah (keberkatan), pensucian, serta kesuburan. Sedangkan menurut syara’, zakat diartikan sebagai suatu pemberian yang berasal dari jenis harta tertentu yang wajib dan ukuran tertentu pula. Kata Zakat berasal dari kata zaka yang artinya mensucikan.</p>

        <p>Jadi dengan demikian zakat bisa didefinisikan sebagai mengambil sebagian harta yang dimiliki seseorang untuk diberikan kepada mereka yang berhak dengan tujuan untuk membersihkan harta tersebut. Zakat yang merupakan rukun islam yang ke 4 menjadi wajib untuk di tunaikan, yang termasuk kedalam bersyukur kepada Allah dengan segala nikmat yang telah di berikan.</p>

        <p>Firman Allah SWT :</p>
        <blockquote>
            وَهُوَ الَّذِي أَنْشَأَ جَنَّاتٍ مَعْرُوشَاتٍ وَغَيْرَ مَعْرُوشَاتٍ وَالنَّخْلَ وَالزَّرْعَ مُخْتَلِفًا أُكُلُهُ وَالزَّيْتُونَ وَالرُّمَّانَ مُتَشَابِهًا وَغَيْرَ مُتَشَابِهٍ كُلُوا مِنْ ثَمَرِهِ إِذَا أَثْمَرَ وَآتُوا حَقَّهُ يَوْمَ حَصَادِهِ وَلَا تُسْرِفُوا إِنَّهُ لَا يُحِبُّ الْمُسْرِفِينَ
        </blockquote>
        <p>Artinya:</p>
        <p>“Dan Dialah yang menjadikan kebun-kebun yang berjunjung dan yang tidak berjunjung, pohon kurma, tanam-tanaman yang bermacam-macam buahnya, zaitun dan delima yang serupa (bentuk dan warnanya), dan tidak sama (rasanya). Makanlah dari buahnya (yang bermacam-macam itu) bila dia berbuah, dan tunaikanlah haknya di hari memetik hasilnya (dengan dikeluarkan zakatnya); dan janganlah kamu berlebih-lebihan. Sesungguhnya Allah tidak menyukai orang-orang yang berlebih-lebihan.” (QS. Al- An’am ayat 141)</p>

        <p>Zakat merupakan rukun islam yang ketiga, dan pelaksanaannya telah diwajibkan oleh Allah SWT jauh sebelum masa Rosulullah Sholallahu Alaihi Wassalam, yaitu sejak zaman Nabi Ibrahim Alaihissalam dan para nabi sesudahnya.</p>

        <p>Hal tersebut sesuai dengan firman-firman Allah SWT berikut :</p>
        <blockquote>
            وَلَقَدْ أَخَذَ اللَّهُ مِيثَاقَ بَنِي إِسْرَائِيلَ وَبَعَثْنَا مِنْهُمُ اثْنَيْ عَشَرَ نَقِيبًا وَقَالَ اللَّهُ إِنِّي مَعَكُمْ لَئِنْ أَقَمْتُمُ الصَّلاةَ وَآتَيْتُمُ الزَّكَاةَ وَآمَنْتُمْ بِرُسُلِي وَعَزَّرْتُمُوهُمْ وَأَقْرَضْتُمُ اللَّهَ قَرْضًا حَسَنًا لأكَفِّرَنَّ عَنْكُمْ سَيِّئَاتِكُمْ وَلأدْخِلَنَّكُمْ جَنَّاتٍ تَجْرِي مِنْ تَحْتِهَا الأنْهَارُ فَمَنْ كَفَرَ بَعْدَ ذَلِكَ مِنْكُمْ فَقَدْ ضَلَّ سَوَاءَ السَّبِيلِ
        </blockquote>
        <p>Artinya:</p>
        <p>“Dan sesungguhnya Allah telah mengambil perjanjian dari Bani Israil dan Kami telah mengangkat dua belas orang pemimpin di antara mereka. Dan Allah berfirman, “Aku bersamamu.” Sesungguhnya jika kamu melaksanakan shalat dan menunaikan zakat serta beriman kepada rasul-rasul-Ku dan kamu bantu mereka dan kamu pinjamkan kepada Allah pinjaman yang baik, pasti akan Aku hapus kesalahan-kesalahanmu, dan pasti akan Aku masukkan ke dalam surga yang mengalir di bawahnya sungai-sungai. Tetapi, barang siapa kafir di antaramu setelah itu, maka sesungguhnya dia telah tersesat dari jalan yang lurus.” (QS. Al- Maidah ayat 12)</p>

        <blockquote>
            وَكَانَ يَأْمُرُ أَهْلَهُ بِالصَّلَاةِ وَالزَّكَاةِ وَكَانَ عِندَ رَبِّهِ مَرْضِيّاً
        </blockquote>
        <p>Artinya “Dan ia (Ismail) menyuruh ahlinya untuk bersembahyang dan menunaikan zakat, dan ia adalah seorang yang diridai di sisi Tuhannya.” (QS. Maryam ayat 55)</p>

        <blockquote>
            وَجَعَلَنِي مُبَارَكاً أَيْنَ مَا كُنتُ وَأَوْصَانِي بِالصَّلَاةِ وَالزَّكَاةِ مَا دُمْتُ حَيّاً
        </blockquote>
        <p>Artinya “Dan Dia menjadikan aku (Isa) seorang yang diberkati di mana saja aku berada, dan Dia memerintahkan kepadaku (mendirikan) salat dan (menunaikan) zakat selama aku hidup.” (QS. Maryam ayat 31)</p>

        <h2>Fungsi dan Hikmah Zakat</h2>
        <p>Zakat merupakan salah satu perwujudan pola hubungan di antara manusia dengan manusia lainnya, dimana zakat memiliki fungsi yang sangat penting dalam kehidupan manusia. Adapun fungsi zakat di antaranya adalah :</p>

        <p>Untuk membersihkan dan mensucikan harta-harta yang didapat. Hal ini sebagaimana Firman Allah SWT berikut :</p>
        <blockquote>
            خُذْ مِنْ أَمْوَالِهِمْ صَدَقَةً تُطَهِّرُهُمْ وَتُزَكِّيهِم بِهَا وَصَلِّ عَلَيْهِمْ إِنَّ صَلَاتَكَ سَكَنٌ لَّهُمْ وَاللَّهُ سَمِيعٌ عَلِيمٌ
        </blockquote>
        <p>Artinya “Ambillah zakat dari sebagian harta mereka, dengan zakat itu kamu membersihkan dan mensucikan mereka dan mendoalah untuk mereka. Sesungguhnya doa kamu itu (menjadi) ketenteraman jiwa bagi mereka. Dan Allah Maha Mendengar lagi Maha Mengetahui.” (QS. At- Taubah ayat 103)</p>

        <p>Dapat menimbulkan rasa kasih sayang dan setia kawan terhadap yang miskin</p>
        <p>Dengan berzakat maka akan menciptakan kehidupan yang lebih baik dan membuat kekayaan tidak terakumulasi pada kelompok-kelompok tertentu saja. Hal ini sesuai dengan Firman Allah SWT dalam Al-Qur’an Surat Al Hasyr ayat 7 :</p>
        <blockquote>
            مَا أَفَاءَ اللَّهُ عَلَى رَسُولِهِ مِنْ أَهْلِ الْقُرَى فَلِلَّهِ وَلِلرَّسُولِ وَلِذِي الْقُرْبَى وَالْيَتَامَى وَالْمَسَاكِينِ وَابْنِ السَّبِيلِ كَيْ لا يَكُونَ دُولَةً بَيْنَ الأغْنِيَاءِ مِنْكُمْ وَمَا آتَاكُمُ الرَّسُولُ فَخُذُوهُ وَمَا نَهَاكُمْ عَنْهُ فَانْتَهُوا وَاتَّقُوا اللَّهَ إِنَّ اللَّهَ شَدِيدُ الْعِقَابِ
        </blockquote>
        <p>Artinya:</p>
        <p>“Harta rampasan fai’i yang diberikan Allah kepada Rasul-Nya (yang berasal) dari penduduk beberapa negeri, adalah untuk Allah, rasul, kerabat (rasul), anak-anak yatim, orang-orang miskin dan untuk orang-orang yang dalam perjalanan, agar harta itu jangan hanya beredar di antara orang-orang kaya saja di antara kamu. Apa yang diberikan Rasul kepadamu, maka terimalah. Dan apa yang dilarangnya bagimu, maka tinggalkanlah. Dan bertakwalah kepada Allah. Sungguh, Allah sangat keras hukumannya.” (QS. Al- Hasyr ayat 7)</p>

        <p>Memperkecil jurang pemisah antara yang kaya dan yang miskin</p>
        <p>Sebagai bentuk pelaksanaan amal ibadah manusia sebagai makhluk sosial</p>
        <p>Mendorong manusia untuk mendapatkan harta benda.</p>

        <h2>Hukum Zakat</h2>
        <p>Zakat memiliki kedudukan yang penting dalam islam, dimana hal tersebut merupakan salah satu unsur pembangun dalam islam. Sebagaimana Sabda Rasulullah Shalallahu Alaihi wassalam :</p>
        <blockquote>
            بني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمداً رسول الله، وإقام الصلاة، وإيتاء الزكاة، والحج، وصوم رمضان
        </blockquote>
        <p>Artinya “Islam dibangun di atas lima perkara: Bersaksi tiada Tuhan selan Allah dan Nabi Muhammad utusan Allah, mendirikan shalat, mengeluarkan zakat, menunaikan haji dan puasa ramadhan”. (HR. Bukhari dan Muslim)</p>

        <p>Adapun hukum zakat menurut islam adalah wajib ain, termasuk bayi yang baru lahirpun telah diwajibkan untuk menunaikan rukun islam yang ketiga tersebut, yaitu dengan tanggungan orang tuanya. Allah SWT berfirman :</p>
        <blockquote>
            و اقیموا الصلاة و آتوا الزکاة و ارکعوا مع الراکعین
        </blockquote>
        <p>Artinya “Dan dirikanlah shalat, tunaikan zakat dan ruku’lah beserta orang-orang yang ruku’.” (QS. Al- Baqarah ayat 43)</p>

        <blockquote>
            وَمَا أُمِرُوا إِلَّا لِيَعْبُدُوا اللَّهَ مُخْلِصِينَ لَهُ الدِّينَ حُنَفَاءَ وَيُقِيمُوا الصَّلَاةَ وَيُؤْتُوا الزَّكَاةَ ۚ وَذَٰلِكَ دِينُ الْقَيِّمَةِ
        </blockquote>
        <p>Artinya “Padahal mereka tidak disuruh kecuali menyembah Allah SWT dengan memurnikan ketaatan kepada-Nya dalam (menjalankan) agama dengan lurus, dan supaya mereka mendirikan shalat dan menunaikan zakat, dan yang demikian itulah agama yang lurus. “ ( Q.S. Al-Bayyinah ayat 5 )</p>
        <h2>Golongan Yang Berhak Menerima Zakat</h2>
        <p>Allah SWT berfirman :</p>
        <blockquote>
            إِنَّمَا الصَّدَقَاتُ لِلْفُقَرَاءِ وَالْمَسَاكِينِ وَالْعَامِلِينَ عَلَيْهَا وَالْمُؤَلَّفَةِ قُلُوبُهُمْ وَفِي الرِّقَابِ وَالْغَارِمِينَ وَفِي سَبِيلِ اللَّهِ وَابْنِ السَّبِيلِ فَرِيضَةً مِنَ اللَّهِ وَاللَّهُ عَلِيمٌ حَكِيمٌ
        </blockquote>
        <p>Artinya:</p>
        <p>“Sesungguhnya zakat-zakat, hanyalah untuk orang-orang fakir, orang-orang miskin, pengelola-pengelolanya, para mu’allaf, serta untuk para budak, orang-orang yang berhutang, dan pada sabilillah, dan orang-orang yang sedang dalam perjalanan, sebagai sesuatu ketetapan yang telah diwajibkan Allah. Dan Allah maha mengetahui lagi maha bijaksana”. (QS. At-Taubah: 60)</p>

        <p>Ayat di atas telah menyatakan bahwasannya terdapat 8 golongan umat yang berhak mendapatkan zakat, yakni :</p>
        <ul>
            <li>Fakir (لِلْفُقَرَاءِ), yaitu orang-orangyang tidak memiliki harta dan juga pekerjaan atau dengan kata lain fakir merupakan orang yang berada pada peringkat ekonomi yang rendah (tidak dapat mencukupi kebutuhan mereka)</li>
            <li>Miskin (الْمَسكِيْنِوَ), yaitu mereka yang memiliki pekerjaan akan tetapi penghasilan yang didapatkan tidak mampu mencukupi kebutuhan hidupnya.</li>
            <li>Amil Zakat (الْعمِلِيْنَ عَلَيهَا), yaitu pengurus-pengurus zakat yang merupakan orang yang bertindak ebagai panitia zakat dimana tugasnya mulai dari menarik zakat hingga membagi-bagikan zakat yang terkumpul kepada yang berhak.</li>
            <li>Muallaf (الْمُؤَلّفَةِ) , yaitu orang-orang yang baru masuk islam</li>
            <li>Riqob (الرقاب), yaitu orang-orang yang berusaha memerdekakan diri mereka dari objeck pemerasan seperti perbudakan dengan cara membayar tebusan.</li>
            <li>Gharim (الْغَارِمِيْنَ), yaitu orang-orang yang terbelenggu oleh hutang, dimana hutang tersebut digunakan untuk dirinya sendiri maupun untuk mendamaikan orang-orang yang sedang berselisih, atu juga karena digunakan untuk menjamin hutang orang lain.</li>
            <li>Fii sabilillah (فِي سَبِيلِ اللَهِ), yaitu orang-orang yang berjuang di jalan Allah SWT tanpa menerima imbalan apapun, seperti dalam pembangunan masjid, sarana pendidikan, dan lain sebagainya.</li>
            <li>Ibnu Sabil (بن السبيل), yaitu mereka yang sedang dalam perjalanan ia kehabisan perbekalan, meskipun sebenarnya orang tersebut adalah orang yang kaya. Ibnu sabil juga berlaku bagi mereka yang sedang menuntut ilmu yang memerlukan beasiswa untuk pendidikannya.</li>
        </ul>

        <h2>Macam – Macam Zakat</h2>
        <p>Allah SWT memerintahkah umat-Nya untuk mengeluarkan zakat adalah dengan tujuan agar harta-harta yang dimiliki menjadi bersih dan suci, karena jika tidak dikeluarkan zakatnya harta-harta tersebut akan menjadi kotor dan haram, dikarenakan harta tersebut bercampur dengan hak orang lain yang dititipkan Allah SWT kepada orang-orang yang diwajibkan untuk berzakat.</p>

        <p>Hal ini sebagaimana firman Allah SWT dalam Al-Qur’an Surat Az- Zarriyat ayat 19 berikut :</p>
        <blockquote>
            وَفِي أَمْوَالِهِمْ حَقٌّ لِلسَّائِلِ وَالْمَحْرُومِ
        </blockquote>
        <p>Artinya “Dan pada harta benda mereka ada hak untuk orang miskin yang meminta, dan orang miskin yang tidak meminta. (QS. Az-Zariyat ayat 19)</p>

        <h3>1. Zakat Mal</h3>
        <p>Zakat Mal juga disebut sebagai zakat harta, artinya zakat yang wajib dikeluarkan oleh setiap umat islam yang memiliki harta benda apabila sudah mencapai nishab atau jumlah tertentu. Zakat Maal telah diwajibkan Allah SWT sebelum Rasulullah Sholallahu Alaihi Wassalam hijrah ke Madinah.</p>

        <p>Dalam sebuah hadist, Beliau Sholallahu Alaihi Wassalam bersabda :</p>
        <blockquote>
            اِنَّ اللهَ فَرَضَ عَلَ اَغْنِيَاءِاْلْمُسْلِمِيْنَ فِيْ اَمْوَالِهِمْ يَقُوْ لُ الَّذِيْ يَسَعُ فُقَرَاءهُمْ وَلَمْ يَجْهَدُ الْفُقَرَاءُاِذَاجَائُوْااوْغُرُوْااِلاَّبِمَا يَصْنَعُ اَغْنِيَا ئُوْ هُمْ اِلاَّوَاِنَّ اللهَ يُحَا سِبُهُمُ حِسَا بًا شَدِيْدًاوِيُعَذِّبُهُمْ عَذَابًااَلِيْمًا
        </blockquote>
        <p>Artinya:</p>
        <p>“Sesungguhnya Allah mewajibkan zakat pada harta orang-orang kaya dari kaum muslimin sejumlah yang dapat melapangi orang-orang miskin di antara mereka. Fakir miskin itu tiadalah menderita menghadapi kelaparan dan kesulitan sandang, kecuali perbuatan golongan orang kaya. Ingatkan Allah akan mengadili mereka nanti secara tegas dan menyiksa mereka dengan pedih ( HR. At-Tabrani )</p>

        <p>ketentuan harta yang wajib dikeluarkan zakatnya antara lain</p>
        <ul>
            <li>Harta tersebut dimiliki sepenuhnya oleh wajib zakat, artinya harta yang wajib dikeluarkan zakatnya adalah harta yang tidak berasal dari hutang atau pinjaman.</li>
            <li>Harta yang wajib dikeluarkan zakatnya adalah harta yang dapat berkembang</li>
            <li>Harta yang wajib dikeluarkan zakatnya adalah harta yang sudah mencapai nishab (ambang batas minimal)</li>
            <li>Harta yang wajib dikeluarkan zakatnya adalah harta yang telah melebihi kebutuhan pokok</li>
            <li>Wajib pajak merupakan orang yang tidak memiliki tanggungan hutang (bebas dari hutang)</li>
            <li>Harta yang wajib dikeluarkan zakatnya telah sampai pada haul (satu tahun)</li>
        </ul>

        <p>Sedangkan jenis-jenis harta yang wajib dikeluarkan zakatnya antara lain adalah :</p>
        <h4>1. Emas dan Perak</h4>
        <p>Allah SWT berfirman :</p>
        <blockquote>
            يَا أَيُّهَا الَّذِينَ آمَنُوا إِنَّ كَثِيرًا مِنَ الْأَحْبَارِ وَالرُّهْبَانِ لَيَأْكُلُونَ أَمْوَالَ النَّاسِ بِالْبَاطِلِ وَيَصُدُّونَ عَنْ سَبِيلِ اللَّهِ ۗ وَالَّذِينَ يَكْنِزُونَ الذَّهَبَ وَالْفِضَّةَ وَلَا يُنْفِقُونَهَا فِي سَبِيلِ اللَّهِ فَبَشِّرْهُمْ بِعَذَابٍ أَلِيمٍ
        </blockquote>
        <p>Artinya:</p>
        <p>“Hai orang-orang yang beriman, sesungguhnya sebahagian besar dari orang-orang alim Yahudi dan rahib-rahib Nasrani benar-benar memakan harta orang dengan jalan yang bathil dan mereka menghalang-halangi (manusia) dari jalan Allah. Dan orang-orang yang menyimpan emas dan perak dan tidak menafkahkannya pada jalan Allah, maka beritahukanlah kepada mereka, (bahwa mereka akan mendapat) siksa yang pedih.” (QS. At- taubah ayat 34)</p>

        <p>Ayat di atas telah menunjukkan adanya kewajiban bagi setiap hamba Allah SWT untuk menafkahkan sebagian harta dalam bentuk emas dan perak di jalan yang diridhoi Allah SWT, karena jika tidak, maka sesungguhnya siksa Allah SWT akan lebih pedih. Bilamanakah seseorang yang menyimpan emas dan perak harus mengeluarkan zakatnya?</p>

        <p>Seperti yang telah dijelaskan di atas bahwasannya zakat atas harta tersebut wajib dikeluarkan apabila telah mencapai nishab dan harta tersebut telah sampai pada haul (sudah mencapai setahun).</p>

        <p>Adapun nishab dari emas adalah 85 gram, sedangkan untuk perak adalah 672 gram. Jika seorang muslim telah memenuhi persyaratan tersebut, maka diwajibkan atasnya untuk mengeluarkan zakat sebesar 2,5% dari harta-harta tersebut.</p>

        <h4>2. Peternakan</h4>
        <p>Islam telah mengelompokkan zakat hewan ternak ke dalam 3 golongan, yaitu :</p>

        <p>Unta Nishab dari unta adalah 5, artinya apabila seseorang memiliki unta dengan jumlah minimal 5 ekor, maka orang tersebut wajib mengeluarkan zakat atas hewan ternaknya tersebut. Untuk rincian nishab dari unta dan berapakah zakat yang wajib dikeluarkan adalah sebagai berikut :</p>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Jumlah unta yang dimiliki</th>
                    <th>Jumlah zakat yang harus dikeluarkan</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>5 – 10 ekor</td><td>1 ekor kambing/domba</td><td>Untuk kambing harus berusia lebih dari dua tahun atau lebih sedangkan domba harus berusia satu tahun atau lebih</td></tr>
                <tr><td>10 – 14 ekor</td><td>2 ekor kambing/ domba</td><td>SDA</td></tr>
                <tr><td>15 – 19 ekor</td><td>3 ekor kambing/ domba</td><td>SDA</td></tr>
                <tr><td>20 – 24 ekor</td><td>4 ekor kambing/domba</td><td>SDA</td></tr>
                <tr><td>25 – 35 ekor</td><td>1 ekor unta betina</td><td>Umur 1 tahun atau masuk tahun ke-2</td></tr>
                <tr><td>36 – 45 ekor</td><td>1 ekor unta betina</td><td>Umur 2 tahun atau masuk tahun ke-3</td></tr>
                <tr><td>46 – 60 ekor</td><td>1 ekor unta betina</td><td>Umur 3 tahun atau masuk tahun ke-4</td></tr>
                <tr><td>61 – 75 ekor</td><td>1 ekor unta betina</td><td>Umur 4 tahun atau masuk tahun ke-5</td></tr>
                <tr><td>76 – 90 ekor</td><td>2 ekor unta betina</td><td>Umur 2 tahun atau masuk tahun ke-3</td></tr>
                <tr><td>91 – 120 ekor</td><td>2 ekor unta betina</td><td>Umur 3 tahun atau masuk tahun ke-4</td></tr>
            </tbody>
        </table>

        <p>Kerbau / sapi Nishab atau batas minimal kepemilikan hewan ternak sapi atau kerbau yang wajib dikeluarkan zakatnya adalah sejumlah 30 ekor dan kepemilikannya adalah telah mencapai satu tahun atau lebih. Berikut rincian perhitungan nishab zakat sapi dan kerbau.</p>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Jumlah sapi/ kerbau yang dimiliki</th>
                    <th>Zakat yang harus dikeluarkan</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>30 – 39 ekor</td><td>1 ekor sapi/ kerbau</td><td>Berumur 1 hingga 2 tahun</td></tr>
                <tr><td>40 – 59 ekor</td><td>1 ekor sapi/ kerbau</td><td>Berumur 2 hingga 3 tahun</td></tr>
                <tr><td>60 – 69 ekor</td><td>2 ekor sapi/kerbau</td><td>Berumur 1 hingga 2 tahun</td></tr>
                <tr><td>70 – 79 ekor</td><td>2 ekor sapi/ kerbau</td><td>1 ekor berumur 1 hingga 2 tahun dan 1 ekor berumur 2 hingga 3 tahun</td></tr>
            </tbody>
        </table>

        <p>Kambing/ domba Nishab atau batas minimal kepemilikan hewan ternak berupa kambing/ domba yang wajib dikeluarkan zakatnya adalah apabila telah mencapai 40 ekor, dimana setiap memiliki 40 hingga 120 ekor kambing/ domba maka sipemilik wajib mengeluarkan zakat sebesar 1 ekor kambing/ domba betina yang telah berumur 2 tahun lebih.</p>

        <p>Unggas dan perikanan Sedangkan nishab bagi peternakan unggas maupun usaha perikanan adalah disetarakan dengan nishab kepemilikan emas, yaitu sebesar 85 gram. Adapaun jumlah zakat yang wajib dikeluarkan adalah sebesar 2,5% dari hasil bersih peternakan tersebut (sudah diptong dengan biaya pengelolaan)</p>

        <h4>3. Pertanian</h4>
        <p>Islam telah mengelompokkan besaran zakat yang harus dikeluarkan oleh petani atas hasil dari usahanya tersebut kedalam 2 bagian, yakni :</p>
        <ul>
            <li>Pertanian yang dalam pengairannya tidak memerlukan biaya (misalnya sawah tadah hujan), jumlah zakat yang harus dikeluarkan adalah sebesar 10%</li>
            <li>Pertanian yang pengairannya memerlukan biaya, maka jumlah zakat yang wajib dikeluarkan adalah sebesar 5%</li>
        </ul>
        <p>Lalu bagaimanakah jika dalah pertanian tersebut terdapat sistem kongsi atau kejasama anatar 2 orang atau lebih dalam pengelolaannya? Dalam kasus tersebut tidak diwajibkan untuk mengeluarkan zakat, kecuali hasil bersih dari pertanian yang dimiliki oleh masing-masing pihak telah mencapai nishab.</p>

        <h4>4. Perniagaan / jasa</h4>
        <p>Zakat perniagaan pada dasarnya dikeluarkan pada setiap tahun fiskal (tahun tutup buku), dimana untuk perhitungannya adalah berdasarkan pada laba bersih yang diperoleh. Nishab (batas minimal) dari harta perniagaan tersebut adalah setara dengan nishab emas yaitu sebesar 85 gram dan zakat yang dikeluarkan adalah sebesar 2,5%.</p>

        <h4>5. Pertambangan</h4>
        <p>Semua hasil pertambangan baik yang berbentuk padat maupun cair juga wajib dikeluarkan zakatnya. Adapun nishabnya adalah disetarakan dengan emas yaitu 85 gram. Sedangkan untuk besaran zakatnya terbagi menjadi 2 kelompok, yaitu :</p>
        <ul>
            <li>Jika barang tambang tersebut diperoleh dengan menggunakan biaya, maka besarnya zakat yang harus dikeluarkan adalah sebesar 2,5 %</li>
            <li>Jika barang tambang tersebut diperoleh dengan tidak mengeluarkan biaya apapun, maka besarnya zakat yang harus dibayarkana dalah sebesar 20%</li>
        </ul>

        <h4>6. Rikaz (barang temuan)</h4>
        <p>Ini merupakan harta temuan yang berasal dari harta-harta terpendam (misalnya harta karun). Jumlah nishabnya adalah setara dengan nishab emas, dan zakat yang wajib dikeluarkan adalah sebesar 20%.</p>

        <h4>7. Profesi</h4>
        <p>Nishab untuk gaji dari suaru profesi adalah disetarakan dengan nishab emas, dan besarnya zakat yang dikeluarkan adalah sebesar 2,5%.</p>

        <h3>2. Zakat Fitrah</h3>
        <p>Ini adalah zakat yang wajib dikeluarkan oleh setiap umat muslim, baik laki-laki maupun perempuan, anak-anak, dewasa, maupun yang telah lanjut usia menjelang berakhirnya bulan ramadhan. Para ulama dari mahdzab Syafi’i berpendapat bahwa zakat fitrah bisa dikeluarkan pada awal ramadhan. Sedangkan batas akhir pembayarannya adalah terbenamnya matahari di akhir ramadhan.</p>

        <p>Adapun dalil yang menyatakan tentang kewajiban mengeluarkan zakat fitrah adalah sebagai berikut :</p>
        <blockquote>
            فَرَضَ رَسُوْلُ اللهِ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ زَكَاةَ الْفِطْرِطُهْرَةً لِلصَّائِمِ وَطُعْمَةً لِلْمَسَا كِيْنِ, فَمَنْ اَدَّاهَاقَبْلَ الصَّلاِةِفَهِيَ زَكَاةٌمَقْبُولَة,ٌ وَمَنْ اَدَّاهَابَعْدَ الصَّلاَةِفَهِيَ صَدَ قَةٌ مِنَ الصَّدَقَاتِ
        </blockquote>
        <p>Artinya:</p>
        <p>“Rasulullah saw. mewajibkan zakat fitrah untuk membersihkan orang yang berpuasa dari hal-hal yang tidak bermanfaat, kata-kata kotor, dan memberi makan orang-orang miskin. Barang siapa mengeluarkannya sebelum shalat Idul Fitri , zakatnya diterima , dan barang siapa yang mengeluarkannya setelah shalat idul fitri, hal itu merupakan salah satu dari sedekah (HR. Abu Dawud)</p>

        <blockquote>
            رَسُوْلُ اللهِ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ فَرَضَ زَكَا ةَ الْفِطْرِ مِنْ رَمَضَانَ عَلَى النَّاسِ صَا عًامِنْ تَمَرٍاَوْصَاعًامِنْ شَعِيْرٍ عَلَى كُلِّ حُرِّ اَوْ عَبْدٍ ذَكِرٍاَوْاُنْثَى مِنَ الْمُسْلِمِيْنَ
        </blockquote>
        <p>Artinya “Rasulullah saw. mewajibkan zakat fitrah pada bulan Ramadlan kepada semua orang Islam, orang yang merdeka, atau hamba sahaya laki-laki atau perempuan, sebanyak 1 sha’ (3,1 liter) kurma atau gandum.” (HR.Muslim)</p>

        <p>Dari hadist-hadist di atas, telah terang bagi kita bahwa zakat fitrah merupakan salah satu kewajiban yang harus dilaksanakan oleh setiap umat muslim pada bulan suci ramadhan, yaitu dengan memberikan sebagian harta yang dimiliki berupa kurma, gandum, maupun makanan pokok lainnya seperti beras, jagung, sagu, dan lain sebagainya sebanyak 2,5 kg atau setara dengan 3,1 liter.</p>

        <p>Beberapa ketentuan yang wajib dipenuhi bagi wajib pajak, seperti :</p>
        <ul>
            <li>Beragama islam</li>
            <li>Zakat fitrah wajib dikeluarkan sebelum terbenamnya matahari di akhir bulan ramadhan atau sebelum terbitnya fajar pada tanggal 1 syawal</li>
            <li>Wajib zakat adalah orang yang mampu menafkahi dirinya sendiri maupun keluarganya</li>
            <li>Dan wajib pajak merupakan orang-orang yang tidak berada dalam tanggungan orang lain.</li>
        </ul>

        <p>Source from <a href="https://dalamislam.com/landasan-agama/fiqih/zakat-dalam-islam" target="_blank" rel="noopener noreferrer">https://dalamislam.com/landasan-agama/fiqih/zakat-dalam-islam</a></p>
    </div>
</div>
@endsection
