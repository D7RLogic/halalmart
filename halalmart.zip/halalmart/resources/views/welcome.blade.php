<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>HalalMart</title>

        <!-- Fonts -->
        <link href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
            /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */
            html {
                line-height: 1.15;
                -webkit-text-size-adjust: 100%;
            }
            body {
                margin: 0;
                font-family: 'Nunito', sans-serif;
                background-color: #f9fafb;
                color: #333;
            }
            a {
                background-color: transparent;
                color: #ef3b2d;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
            .container {
                max-width: 960px;
                margin: 0 auto;
                padding: 2rem;
                text-align: center;
            }
            h1 {
                font-size: 3rem;
                margin-bottom: 1rem;
            }
            p {
                font-size: 1.25rem;
                margin-bottom: 2rem;
            }
            .btn {
                display: inline-block;
                padding: 0.75rem 1.5rem;
                font-size: 1rem;
                font-weight: 600;
                color: #fff;
                background-color: #ef3b2d;
                border-radius: 0.375rem;
                transition: background-color 0.3s ease;
            }
            .btn:hover {
                background-color: #c32a1f;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Welcome to HalalMart</h1>
            <p>Your trusted marketplace for halal products.</p>
            @if (Route::has('login'))
                <div>
                    @auth
                        <a href="{{ url('/dashboard') }}" class="btn">Go to Dashboard</a>
                    @else
                        <a href="{{ route('login') }}" class="btn">Log in</a>
                        @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="btn" style="margin-left: 1rem;">Register</a>
                        @endif
                    @endauth
                </div>
            @endif
        </div>
    </body>
</html>
