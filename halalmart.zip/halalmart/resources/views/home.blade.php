@extends('layouts.app')

@section('title', 'Beranda')

@section('content')
<!-- Hero Banner with smaller images matching latest products size -->
<div class="mb-5">
    <div id="heroCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner rounded">
@php
    $heroBannerProducts = $heroBannerProducts ?? collect();
@endphp

@foreach ($heroBannerProducts as $index => $product)
<div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                @if($product->image)
                <img src="{{ asset('storage/' . $product->image) }}" class="d-block mx-auto" style="max-height: 200px; width: auto;" alt="{{ $product->name }}">
                @else
                <img src="https://via.placeholder.com/300x200?text=No+Image" class="d-block mx-auto" alt="{{ $product->name }}">
                @endif
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded p-3">
                    <h5>{{ $product->name }}</h5>
                    <p>{{ \Illuminate\Support\Str::limit($product->description, 100) }}</p>
                    <a href="{{ route('product.show', $product->id) }}" class="btn btn-primary">Lihat Produk</a>
                </div>
            </div>
            @endforeach
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</div>

<!-- Featured Categories -->
<section class="mb-5">
    <h2 class="mb-4">Kategori Pilihan</h2>
    <div class="row">
        @foreach ($categories as $category)
        <div class="col-6 col-md-3 mb-3">
            <div class="card h-100 text-center">
                <div class="card-body d-flex flex-column justify-content-center">
                    <h5 class="card-title">{{ $category }}</h5>
                    <a href="{{ route('category.filter', $category) }}" class="btn btn-outline-primary mt-auto">Lihat Produk</a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</section>

<!-- Latest Products -->
<section class="mb-5">
    <h2 class="mb-4">Produk Terbaru</h2>
    <div class="row">
        @foreach ($latestProducts as $product)
        <div class="col-6 col-sm-6 col-md-4 col-lg-3 mb-4">
            <div class="card h-100">
                @if($product->image)
                <img src="{{ asset('storage/' . $product->image) }}" class="card-img-top img-fluid" alt="{{ $product->name }}">
                @else
                <img src="https://via.placeholder.com/300x200?text=No+Image" class="card-img-top img-fluid" alt="{{ $product->name }}">
                @endif
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">{{ $product->name }}</h5>
                    <p class="card-text text-truncate">{{ \Illuminate\Support\Str::limit($product->description, 80) }}</p>
                    <a href="{{ route('product.show', $product->id) }}" class="btn btn-primary mt-auto">Lihat Produk</a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</section>

<!-- Promotional Banner -->
<section class="mb-5">
    <div class="p-4 bg-light rounded text-center border">
        <h4>Promo Spesial</h4>
        <p>Dapatkan diskon menarik untuk produk pilihan kami.</p>
        <img src="https://via.placeholder.com/728x90?text=Promo+Banner" alt="Promo Banner" class="img-fluid mx-auto d-block">
    </div>
</section>

@endsection
