@extends('layouts.app')

@section('title', 'Purchase Summary')

@section('content')
<div class="mt-4">
    <h1>Purchase Summary</h1>

    <div class="card mb-3" style="max-width: 540px;">
        <div class="row g-0">
            <div class="col-md-4">
                @if($orderData['product']->image)
                <img src="{{ asset('storage/' . $orderData['product']->image) }}" class="img-fluid rounded-start" alt="{{ $orderData['product']->name }}">
                @else
                <img src="https://via.placeholder.com/150" class="img-fluid rounded-start" alt="{{ $orderData['product']->name }}">
                @endif
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title">{{ $orderData['product']->name }}</h5>
                    <p class="card-text">{{ $orderData['product']->description }}</p>
                    <p class="card-text"><strong>Harga: Rp {{ number_format($orderData['product']->price, 0, ',', '.') }}</strong></p>
                    <p class="card-text"><strong>Donation: Rp {{ number_format($orderData['donation'], 0, ',', '.') }}</strong></p>
                    <p class="card-text"><strong>Total: Rp {{ number_format($orderData['total'], 0, ',', '.') }}</strong></p>
                    <p class="card-text"><strong>Buyer Name: </strong>{{ $orderData['name'] }}</p>
                    <p class="card-text"><strong>Address: </strong>{{ $orderData['address'] }}</p>
                    <p class="card-text"><strong>Payment Method: </strong>{{ ucfirst($orderData['payment_method']) }}</p>
                </div>
            </div>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="mt-3">
        <form method="POST" action="{{ route('purchase.confirm') }}">
            @csrf
            <button type="submit" class="btn btn-success ms-2">Buy Now</button>
            <a href="{{ route('home') }}" class="btn btn-primary">Back to Home</a>
        </form>
    </div>
</div>
@endsection
