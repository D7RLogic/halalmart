@extends('layouts.app')

@section('title', 'Kalkulator Zakat')

@section('content')
<div class="card mx-auto" style="max-width: 900px;">
    <div class="card-body">
        <h1 class="card-title mb-4">Kalkulator Zakat</h1>

        <a href="{{ route('pengertian.zakat') }}" class="btn btn-info mb-4">Pengertian Zakat</a>

        <form method="POST" action="{{ route('zakat.calculate') }}">
            @csrf
            <div class="mb-3">
                <label for="type" class="form-label">Jenis Zakat</label>
                <select class="form-select" id="type" name="type" required>
                    <option value="" disabled selected>Pilih jenis zakat</option>
                    <option value="maal" {{ old('type') == 'maal' ? 'selected' : '' }}>Zakat Maal (Harta)</option>
                    <option value="fitrah" {{ old('type') == 'fitrah' ? 'selected' : '' }}>Zakat Fitrah (Orang)</option>
                </select>
                @error('type')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="amount" class="form-label">Jumlah</label>
                <input type="number" class="form-control" id="amount" name="amount" value="{{ old('amount') }}" min="0" step="any" required>
                <div class="form-text">Masukkan jumlah harta (untuk Zakat Maal) atau jumlah orang (untuk Zakat Fitrah)</div>
                @error('amount')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>

            <button type="submit" class="btn btn-primary">Hitung Zakat</button>
        </form>

        @isset($zakat)
        <div class="alert alert-success mt-4" role="alert">
            <h4 class="alert-heading">Hasil Perhitungan Zakat</h4>
            <p>Jenis Zakat: <strong>{{ ucfirst($type) }}</strong></p>
            <p>Jumlah: <strong>{{ $amount }}</strong></p>
            <p>Zakat yang harus dikeluarkan: <strong>Rp {{ number_format($zakat, 0, ',', '.') }}</strong></p>
        </div>
        @endisset
    </div>
    <label for="type" class="form-label">NB:zakat perorangan tergantung beras/nasi yang kita gunakan</label>
</div>
@endsection
