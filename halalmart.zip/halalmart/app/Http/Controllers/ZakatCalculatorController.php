<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ZakatCalculatorController extends Controller
{
    public function index()
    {
        return view('zakat_calculator');
    }

    public function calculate(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:0',
            'type' => 'required|string|in:maal,fitrah',
        ]);

        $amount = $request->input('amount');
        $type = $request->input('type');
        $zakat = 0;

        if ($type === 'maal') {
            // Zakat maal is 2.5% of amount
            $zakat = $amount * 0.025;
        } elseif ($type === 'fitrah') {
            // Zakat fitrah fixed amount per person, assume amount input is number of persons
            // For example, fixed rate 50,000 per person
            $fixedRate = 50000;
            $zakat = $amount * $fixedRate;
        }

        return view('zakat_calculator', compact('zakat', 'amount', 'type'));
    }

    public function pengertian()
    {
        return view('pengertian_zakat');
    }
}
