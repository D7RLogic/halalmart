<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class HomeController extends Controller
{
    public function index()
    {
        $heroBannerProducts = Product::whereNotNull('image')->orderBy('created_at', 'desc')->take(3)->get();
        // Fetch only 3 newest products for latest products section
        $latestProducts = Product::orderBy('created_at', 'desc')->take(3)->get();
        $categories = Product::select('category')->distinct()->whereNotNull('category')->get()->pluck('category');
        return view('home', compact('heroBannerProducts', 'latestProducts', 'categories'));
    }

    public function filterByCategory($category)
    {
        $latestProducts = Product::where('category', $category)->orderBy('created_at', 'desc')->get();
        $categories = Product::select('category')->distinct()->whereNotNull('category')->get()->pluck('category');
        return view('home', compact('latestProducts', 'categories', 'category'));
    }
}
