<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Order; // Assuming there is an Order model for transactions
use App\Models\Umkm;

class DashboardController extends Controller
{
    public function index()
    {
        // UMKM dashboard for normal user
        $umkms = Umkm::all();
        return view('dashboard', compact('umkms'));
    }

    public function adminDashboard()
    {
        // Fetch products count
        $productsCount = Product::count();

        // Fetch total sales amount (using 'total' field and status)
        $totalSales = Order::where('status', 'completed')->sum('total');

        // Fetch total orders count
        $totalOrders = Order::count();

        return view('admin.dashboard', compact('productsCount', 'totalSales', 'totalOrders'));
    }

    public function financialReport()
    {
        // Fetch completed orders with product details for financial report
        $orders = Order::with('product')
            ->where('status', 'completed')
            ->get();

        return view('admin.reports.financial', compact('orders'));
    }

    public function showAddUmkmForm()
    {
        return view('admin.umkm.add');
    }

    public function storeUmkm(Request $request)
    {
        $validated = $request->validate([
            'nama_umkm' => 'required|string|max:255',
            'alamat' => 'required|string',
            'foto' => 'nullable|image|max:2048',
            'kode_pos' => 'required|string|max:20',
            'nama_pemilik' => 'required|string|max:255',
        ]);

        if ($request->hasFile('foto')) {
            $file = $request->file('foto');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('uploads/umkm'), $filename);
            $validated['foto'] = $filename;
        }

        Umkm::create($validated);

        return redirect()->route('admin.umkm.add')->with('success', 'UMKM added successfully.');
    }
}
