<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Order;
use App\Models\FinancialReport;

class CheckoutController extends Controller
{
    public function showForm(Request $request)
    {
        $productId = $request->query('product');
        $product = null;
        if ($productId) {
            $product = Product::find($productId);
        }
        return view('checkout', compact('product'));
    }

    public function processForm(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'address' => 'required|string',
            'product' => 'required|integer',
            'donation' => 'nullable|numeric|min:0',
            'payWithDonation' => 'nullable|boolean',
            'payment_method' => 'required|string',
        ]);

        $payWithDonation = $request->has('payWithDonation') && $request->input('payWithDonation') == '1';
        $donationAmount = $request->input('donation', 0);

        $product = Product::find($validated['product']);
        if (!$product) {
            return redirect()->back()->withErrors(['product' => 'Product not found']);
        }

        $orderData = [
            'name' => $validated['name'],
            'address' => $validated['address'],
            'product' => $product,
            'donation' => $donationAmount,
            'payWithDonation' => $payWithDonation,
            'payment_method' => $validated['payment_method'],
            'total' => $payWithDonation ? $donationAmount : $product->price + $donationAmount,
        ];

        // Pass order data to purchase summary view
        return view('purchase_summary', compact('orderData'));
    }

    public function purchaseSummary(Request $request)
    {
        // This method can be used if you want to show summary via route
        // For now, purchase summary is shown directly from processForm
        return redirect('/');
    }

    public function confirmPurchase(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'address' => 'required|string',
            'product' => 'required|integer',
            'donation' => 'nullable|numeric|min:0',
            'payWithDonation' => 'nullable|boolean',
            'payment_method' => 'required|string',
            'total' => 'required|numeric',
        ]);

        // Save order to database
        $order = Order::create([
            'total' => $validated['total'],
            'status' => 'completed',
            'product_id' => $validated['product'],
        ]);

        // Create financial report entry
        FinancialReport::create([
            'amount' => $validated['total'],
            'description' => 'Purchase by ' . $validated['name'],
        ]);

        return redirect()->back()->with('success', 'Berhasil di beli');
    }
}
