

<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>
<h1>Form Checkout</h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if($product): ?>
<div class="card mb-3" style="max-width: 540px;">
    <div class="row g-0">
        <div class="col-md-4">
            <?php if($product->image): ?>
            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="img-fluid rounded-start" alt="<?php echo e($product->name); ?>">
            <?php else: ?>
            <img src="https://via.placeholder.com/150" class="img-fluid rounded-start" alt="<?php echo e($product->name); ?>">
            <?php endif; ?>
        </div>
        <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($product->name); ?></h5>
                <p class="card-text"><?php echo e($product->description); ?></p>
                <p class="card-text"><strong>Harga: Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></strong></p>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<p>Produk tidak ditemukan.</p>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('checkout.process')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="product" value="<?php echo e($product ? $product->id : ''); ?>">
    <div class="mb-3">
        <label for="name" class="form-label">Nama</label>
        <input type="text" class="form-control" id="name" name="name" required>
    </div>
    <div class="mb-3">
        <label for="address" class="form-label">Alamat</label>
        <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
    </div>
    <div class="mb-3">
        <label for="donation" class="form-label">Sedekah (donasi)</label>
        <input type="number" class="form-control" id="donation" name="donation" min="0" value="0">
    </div>
    <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="payWithDonation" name="payWithDonation" value="1">
        <label class="form-check-label" for="payWithDonation">Bayar dengan Sedekah</label>
    </div>
    <div class="mb-3">
        <label for="payment_method" class="form-label">Metode Pembayaran</label>
        <select class="form-select" id="payment_method" name="payment_method" required>
            <option value="">Pilih Metode Pembayaran</option>
            <option value="qris">QRIS</option>
            <option value="bca">BCA</option>
            <option value="mandiri">Mandiri</option>
            <option value="bri">BRI</option>
        </select>
    </div>
    <button type="submit" class="btn btn-primary">Checkout</button>
    <a href="<?php echo e($product ? route('product.show', $product->id) : route('home')); ?>" class="btn btn-secondary ms-2">Batal</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\halalmart\resources\views/checkout.blade.php ENDPATH**/ ?>