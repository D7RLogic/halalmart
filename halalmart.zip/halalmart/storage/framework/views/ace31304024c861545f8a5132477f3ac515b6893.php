

<?php $__env->startSection('title', 'Add New Product'); ?>

<?php $__env->startSection('content'); ?>
<h1>Add New Product</h1>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('admin.products.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="name" class="form-label">Product Name *</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea class="form-control" id="description" name="description"><?php echo e(old('description')); ?></textarea>
    </div>
    <div class="mb-3">
        <label for="price" class="form-label">Price (Rp) *</label>
        <input type="number" class="form-control" id="price" name="price" value="<?php echo e(old('price')); ?>" min="0" step="0.01" required>
    </div>
    <div class="mb-3">
        <label for="category" class="form-label">Category</label>
        <input type="text" class="form-control" id="category" name="category" value="<?php echo e(old('category')); ?>">
    </div>
    <div class="mb-3">
        <label for="image" class="form-label">Product Image (jpg, png, max 2MB)</label>
        <input type="file" class="form-control" id="image" name="image" accept="image/*">
    </div>
    <div class="mb-3">
        <label for="halal_certification" class="form-label">Halal Certification (pdf, jpg, png, max 5MB)</label>
        <input type="file" class="form-control" id="halal_certification" name="halal_certification" accept=".pdf,image/*">
    </div>
    <div class="mb-3">
        <label for="halal_status" class="form-label">Halal Status</label>
        <input type="text" class="form-control" id="halal_status" name="halal_status" value="Unknown" readonly>
    </div>
    <button type="submit" class="btn btn-primary">Add Product</button>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary">Cancel</a>
</form>

    <script>
    document.getElementById('halal_certification').addEventListener('change', function(event) {
        const fileInput = event.target;
        const halalStatusInput = document.getElementById('halal_status');
        if (fileInput.files.length === 0) {
            // Default to halal if no file selected
            halalStatusInput.value = 'halal';
            return;
        }
        const fileName = fileInput.files[0].name.toLowerCase();

        // Product Product Haram yang nanti auto ditolak
        const haramKeywords = ['babi', 'pork', 'alkohol', 'alcohol', 'wine', 'beer', 'whiskey', 'vodka'];

        let isHaram = haramKeywords.some(keyword => fileName.includes(keyword));

        if (isHaram) {
            halalStatusInput.value = 'haram';
        } else {
            halalStatusInput.value = 'halal';
        }
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\halalmart\resources\views/admin/products/create.blade.php ENDPATH**/ ?>