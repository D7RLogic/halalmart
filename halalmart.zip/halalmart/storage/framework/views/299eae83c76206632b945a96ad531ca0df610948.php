

<?php $__env->startSection('title', 'Purchase Summary'); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-4">
    <h1>Purchase Summary</h1>

    <div class="card mb-3" style="max-width: 540px;">
        <div class="row g-0">
            <div class="col-md-4">
                <?php if($orderData['product']->image): ?>
                <img src="<?php echo e(asset('storage/' . $orderData['product']->image)); ?>" class="img-fluid rounded-start" alt="<?php echo e($orderData['product']->name); ?>">
                <?php else: ?>
                <img src="https://via.placeholder.com/150" class="img-fluid rounded-start" alt="<?php echo e($orderData['product']->name); ?>">
                <?php endif; ?>
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($orderData['product']->name); ?></h5>
                    <p class="card-text"><?php echo e($orderData['product']->description); ?></p>
                    <p class="card-text"><strong>Harga: Rp <?php echo e(number_format($orderData['product']->price, 0, ',', '.')); ?></strong></p>
                    <p class="card-text"><strong>Donation: Rp <?php echo e(number_format($orderData['donation'], 0, ',', '.')); ?></strong></p>
                    <p class="card-text"><strong>Total: Rp <?php echo e(number_format($orderData['total'], 0, ',', '.')); ?></strong></p>
                    <p class="card-text"><strong>Buyer Name: </strong><?php echo e($orderData['name']); ?></p>
                    <p class="card-text"><strong>Address: </strong><?php echo e($orderData['address']); ?></p>
                    <p class="card-text"><strong>Payment Method: </strong><?php echo e(ucfirst($orderData['payment_method'])); ?></p>
                </div>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="mt-3">
        <form method="POST" action="<?php echo e(route('purchase.confirm')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-success ms-2">Buy Now</button>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Back to Home</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\halalmart\resources\views/purchase_summary.blade.php ENDPATH**/ ?>