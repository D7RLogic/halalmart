<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Halalmart'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-success mb-4">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Halalmart</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('checkout.form')); ?>">Checkout</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard UMKM</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('zakat.calculator')); ?>">Kalkulator Zakat</a></li>
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></li>
                    <?php else: ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <?php if(Auth::user()->name === 'admin'): ?>
                                <li><h6 class="dropdown-header">Admin Tools</h6></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.products.create')); ?>">Add Product</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">Transaction Dashboard</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.reports.financial')); ?>">Financial Report</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.products.index')); ?>">Edit/Delete Products</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.umkm.add')); ?>">Add UMKM Partner</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">Logout</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->make('partials.live_chat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\halalmart\resources\views/layouts/app.blade.php ENDPATH**/ ?>