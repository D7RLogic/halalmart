

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h1>Admin Dashboard</h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card text-white bg-primary mb-3">
            <div class="card-header">Total Products</div>
            <div class="card-body">
                <h3 class="card-title"><?php echo e($productsCount); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-success mb-3">
            <div class="card-header">Total Sales</div>
            <div class="card-body">
                <h3 class="card-title">Rp <?php echo e(number_format($totalSales, 2, ',', '.')); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-info mb-3">
            <div class="card-header">Total Orders</div>
            <div class="card-body">
                <h3 class="card-title"><?php echo e($totalOrders); ?></h3>
            </div>
        </div>
    </div>
</div>

<a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary mb-3">Add New Product</a>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\halalmart\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>