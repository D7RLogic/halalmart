

<?php $__env->startSection('title', 'Manage Products'); ?>

<?php $__env->startSection('content'); ?>
<h1>Manage Products</h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary mb-3">Add New Product</a>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th>
            <th>Category</th>
            <th>Price (Rp)</th>
            <th>Image</th>
            <th>Halal Certification</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->category); ?></td>
            <td><?php echo e(number_format($product->price, 2, ',', '.')); ?></td>
            <td>
                <?php if($product->image): ?>
                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="Product Image" style="max-width: 100px;">
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
            <td>
                <?php if($product->halal_certification): ?>
                    <?php
                        $ext = pathinfo($product->halal_certification, PATHINFO_EXTENSION);
                    ?>
                    <?php if(in_array(strtolower($ext), ['jpg', 'jpeg', 'png', 'gif'])): ?>
                        <img src="<?php echo e(asset('storage/' . $product->halal_certification)); ?>" alt="Halal Certification" style="max-width: 100px;">
                    <?php else: ?>
                        <a href="<?php echo e(asset('storage/' . $product->halal_certification)); ?>" target="_blank">View</a>
                    <?php endif; ?>
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
            <td>
                <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this product?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="text-center">No products found.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php echo e($products->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\halalmart\resources\views/admin/products/index.blade.php ENDPATH**/ ?>