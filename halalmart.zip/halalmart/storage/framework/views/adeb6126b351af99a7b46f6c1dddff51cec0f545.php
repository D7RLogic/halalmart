

<?php $__env->startSection('title', 'Financial Report'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Financial Report</h1>

    <?php if($orders->isEmpty()): ?>
        <p>No financial data available.</p>
    <?php else: ?>
        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Product Name</th>
                    <th>Price (Rp)</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->product ? $order->product->name : 'N/A'); ?></td>
                    <td><?php echo e(number_format($order->total, 2, ',', '.')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary mt-3">Back to Dashboard</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\halalmart\resources\views/admin/reports/financial.blade.php ENDPATH**/ ?>