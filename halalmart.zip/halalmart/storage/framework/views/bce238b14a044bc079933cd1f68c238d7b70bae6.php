

<?php $__env->startSection('title', 'Detail Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <?php if($product->image): ?>
        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="img-fluid" alt="<?php echo e($product->name); ?>">
        <?php else: ?>
        <img src="https://via.placeholder.com/400" class="img-fluid" alt="<?php echo e($product->name); ?>">
        <?php endif; ?>
    </div>
    <div class="col-md-6">
        <h1><?php echo e($product->name); ?></h1>
        <p><?php echo e($product->description); ?></p>
        <h3>Harga: Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></h3>
        <a href="<?php echo e(route('checkout.form', ['product' => $product->id])); ?>" class="btn btn-success">Beli Sekarang</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\halalmart\resources\views/product.blade.php ENDPATH**/ ?>