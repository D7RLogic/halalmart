

<?php $__env->startSection('title', 'Dashboard UMKM'); ?>

<?php $__env->startSection('content'); ?>
<h1><p>Dashboard UMKM</p></h1>
<h5><p>Selamat datang di dashboard UMKM </p></h5>
<h5><p>Berikut adalah mitra mitra yang telah tergabung dengan kita</p></h5>

<?php if($umkms->isEmpty()): ?>
    <p>Tidak ada data UMKM yang tersedia.</p>
<?php else: ?>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card h-100">
                    <?php if($umkm->foto): ?>
                        <img src="<?php echo e(asset('uploads/umkm/' . $umkm->foto)); ?>" class="card-img-top" alt="<?php echo e($umkm->nama_umkm); ?>" style="object-fit: cover; height: 200px;">
                    <?php else: ?>
                        <img src="https://via.placeholder.com/300x200?text=No+Image" class="card-img-top" alt="No Image">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($umkm->nama_umkm); ?></h5>
                        <p class="card-text"><strong>Alamat:</strong> <?php echo e($umkm->alamat); ?></p>
                        <p class="card-text"><strong>Kode Pos:</strong> <?php echo e($umkm->kode_pos); ?></p>
                        <p class="card-text"><strong>Nama Pemilik:</strong> <?php echo e($umkm->nama_pemilik); ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\halalmart\resources\views/dashboard.blade.php ENDPATH**/ ?>